import { Link } from 'react-router';
import './Footer.css';

//
//done
//

export function Footer() {
    return (
        <footer className="footer">
            <div className="container">
                <div className="footer-content">
                    <div className="footer-brand">
                        <h3>Vroom</h3>
                        <p>Making ride-sharing affordable and accessible for everyone in Bangladesh.</p>
                    </div>
                    <div className="footer-links">
                        <div className="footer-column">
                            <h4>Ride</h4>
                            <Link to="/findride">Find Ride</Link>
                            <Link to="/postride">Post Ride</Link>
                        </div>
                        <div className="footer-column">
                            <h4>Others</h4>
                            <Link to="/about">About Us</Link>
                            <Link to="/login">Account</Link>
                        </div>
                    </div>
                </div>
                <div className="footer-bottom">
                    <p>&copy; 2025 Vroom. All rights reserved.</p>
                </div>
            </div>
        </footer>
    );
}