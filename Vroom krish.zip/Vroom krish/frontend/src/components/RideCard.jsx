import { useEffect, useState } from "react";
import axios from "axios";
import "./RideCard.css";
import { getDate, getTime } from "../utils/DateTime";

export function RideCard({ 
  ride, 
  onToggle, 
  showRequest = true,
  showStatus = false,
  proposal
}) {

  const [vh, setVh] = useState({});
  const [requestId, setRequestId] = useState(null);
  const userId = localStorage.getItem("userId");

  useEffect(() => {
  const fetchVh = async () => {
    console.log("Fetching ride:", ride);
    try {
      const vhResponse = await axios.get(`/api/vehicles/${ride.vehicle.id}`);
      if (vhResponse.data) {
        setVh(vhResponse.data);  // Correctly set the vehicle data
      } else {
        console.log("Vehicle data not found for ride:", ride.vehicle.id);
        setVh({});  // Set an empty object if no vehicle data found
      }
    } catch (err) {
      console.error("Error fetching vehicle data:", err);
    }
  };

  fetchVh();
}, [ride.vehicle.id]);  // Ensure `ride.vehicle.id` is correctly passed



  useEffect(() => {
    // Check if user already requested this ride
    const fetchUserRequest = async () => {
      if (!userId) return;
      try {
        const res = await axios.get(`/api/booking/rdrRide?rideId=${ride.rideId}&riderId=${userId}`);
        if (res.data.length > 0) {
          console.log("User has already requested:", res.data[0].id);
          setRequestId(res.data[0].id);
        }
      } catch (err) {
        console.error("Error fetching user request:", err);
      }
    };
    fetchUserRequest();
  }, [ride.rideId, userId]);

  const handleRequestToggle = async () => {
  if (!userId) {
    alert("Please login first.");
    return;
  }

  try {
    if (!requestId) {
      // Create a new request only if one does not exist
      const res = await axios.post("/api/booking", {
        ridePay: {rideId: ride.rideId},
        requester: {id: userId},
        driver: {id: ride.driver.id},
        status: "PENDING",
        locFrom: proposal?.locFrom || ride.locFrom,
        locTo: proposal?.locTo || ride.locTo,
        fare: proposal?.fare || ride.fare
      });
      console.log("New request created:", res.data);
      setRequestId(res.data.bookingId);
    } else {
      // If requestId exists, cancel the request
      await axios.delete(`/api/cancel/${requestId}`);
      console.log("Request canceled:", requestId);
      setRequestId(null);
    }

    if (onToggle) onToggle(); // optional callback to parent
  } catch (err) {
    console.error("Error toggling request:", err);
    alert("Failed to update request. Try again.");
  }
};


  return (
    <div className="ride-card">
      {console.log("Rendering ridecard vehicle:", vh[0])}
      <div className="ride-header">
        <div className="route">
          <div className="departure">
            <span className="label">From</span>
            <span className="location">{ride.locFrom || "-"}</span>
          </div>
          <div className="route-line">
            <div className="dot start"></div>
            <div className="line"></div>
            <div className="dot end"></div>
          </div>
          <div className="destination">
            <span className="label">To</span>
            <span className="location">{ride.locTo || "-"}</span>
          </div>
        </div>
      </div>

      <div className="ride-details">
        <div className="detail">
          <span className="label">Date</span>
          <span className="value">{getDate(ride.rideTime) || "-"}</span>
        </div>
        <div className="detail">
          <span className="label">Time</span>
          <span className="value">{getTime(ride.rideTime) || "-"}</span>
        </div>
        <div className="detail">
          <span className="label">Vehicle</span>
          <span className="value">{vh[0]?.model || "-"}</span>
        </div>
        <div className="detail">
          <span className="label">Fare</span>
          <span className="value price"><b>৳</b>{ride.fare || "-"}</span>
        </div>
      </div>

      {showStatus && (
        <>
          <p>
            <strong>Status:</strong>{" "}
            <span className={`status ${ride.status?.toUpperCase()}`}>
              {ride.status || "PENDING"}
            </span>
          </p>

          {ride.status?.toUpperCase() === "COMPLETE" && (
            <div className="payment-details">
              <p><strong>Paid Amount:</strong> {ride.fare || "N/A"}</p>
              <p><strong>Payment Method:</strong> {ride.method || "N/A"}</p>
              {ride.transactionId && (
                <p><strong>Transaction ID:</strong> {ride.transactionId}</p>
              )}
            </div>
          )}
        </>
      )}

      {showRequest && (
        <button
          className={`request-btn ${requestId ? "cancel" : ""}`}
          onClick={handleRequestToggle}
        >
          {requestId ? "Cancel" : "Request"}
        </button>
      )}
    </div>
  );
}
