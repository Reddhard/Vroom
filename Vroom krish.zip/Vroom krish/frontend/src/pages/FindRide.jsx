import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { RideSearch } from "../components/SearchRide";
import { RideCard } from "../components/RideCard";
import axios from "axios";
import './FindRide.css';

//
//api left
//

export function FindRide() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [rides, setRides] = useState([]);
  const [filteredRides, setFilteredRides] = useState([]);
  const [proposal, setProposal] = useState({ locFrom: "", locTo: "", fare: "" });
  const userId = localStorage.getItem("userId");
  const navigate = useNavigate();

  // Watch for ongoing rides for this passenger
  useEffect(() => {
    if (!userId) return;

    const checkOngoingRide = async () => {
      try {
        const res = await axios.get(`/api/ridepay/rdrStatus?riderId=${userId}&status=ON_GOING`);
        if (res.data.length > 0) {
          navigate("/rating");
        }
      } catch (err) {
        console.error("Failed to check ongoing ride", err);
      }
    };
    checkOngoingRide();
  }, [userId, navigate]);

  useEffect(() => {
    const fetchPendingRides = async () => {
      try {
        const res = await axios.get("/api/ridepays");
        console.log("Fetched rides:", res.data);
        console.log(userId);
        res.data.map(ride => console.log(ride.driver.id));
        const otherRides = res.data.filter(ride => String(ride.driver.id) !== String(userId));
        setRides(otherRides);
        setFilteredRides(otherRides);
        console.log("Other rides:", otherRides);
      } catch (err) {
        console.error("Failed to fetch rides", err);
      }
    };

    fetchPendingRides();
  }, [userId]);

  // Watch for accepted requests for this user
  useEffect(() => {
    if (!userId) return;

    const checkAcceptedRequests = async () => {
      try {
        const res = await axios.get(`/api/booking/rdrStatus?riderId=${userId}&status=ACCEPTED`);
        for (const req of res.data) {
          // Fetch ride details
          const rideRes = await axios.get(`/api/ridepay/${req.rideId}`);
          const ride = rideRes.data;
          if (ride.status === "ON_GOING") {
            // Reject other pending requests for this passenger
            const allReqs = await axios.get(`/api/booking/rdrStatus?riderId=${userId}&status=PENDING`);
            for (const r of allReqs.data) {
              if (r.bookingId !== ride.rideId && r.status === "PENDING") {
                await axios.patch(`/api/booking-u/${r.bookingId}`, { status: "REJECTED" });
              }
            }
            // Redirect to rating only for ongoing ride
            navigate("/rating");
            break;
          }
        }
      } catch (err) {
        console.error("Failed to check accepted requests", err);
      }
    };


    const interval = setInterval(checkAcceptedRequests, 3000); // poll every 3 sec
    return () => clearInterval(interval);
  }, [userId, navigate]);

  // handler for input changes
  const handleProposalChange = (e) => {
    const { name, value } = e.target;
    setProposal((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <>
      <Header />

      <section className="rides-section container">
        <div className="rides-header">
          <h1>Available Rides</h1>
          <button
            className="open-search-btn"
            onClick={() => setSearchOpen(!searchOpen)}
          >
            Search Rides
          </button>
        </div>

        {/* Passenger Proposal Form */}
        {(!!userId) && (<div className="proposal-form">
          <input
            type="text"
            name="locFrom"
            placeholder="From"
            className="proposal-input"
            value={proposal.locFrom}
            onChange={handleProposalChange}
          />
          <input
            type="text"
            name="locTo"
            placeholder="To"
            className="proposal-input"
            value={proposal.locTo}
            onChange={handleProposalChange}
          />
          <input
            type="number"
            name="fare"
            placeholder="Fare"
            className="proposal-input"
            value={proposal.fare}
            onChange={handleProposalChange}
          />
        </div>)}

        <RideSearch
          rides={rides}
          onFilter={setFilteredRides}
          searchOpen={searchOpen}
          setSearchOpen={setSearchOpen}
        />

        {console.log("Rendering filtered rides:", filteredRides)}
        <div className="rides-grid">
          {/* {console.log("Rendering filtered rides:", filteredRides)} */}
          {filteredRides.map((ride) => (
            <RideCard
              key={ride.rideId}
              ride={ride}
              showRequest={!!userId}
              showStatus={false}
              proposal={proposal}
            />
          ))}
        </div>
      </section>

      <Footer />
    </>
  );
}
