import { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { RideCard } from "../components/RideCard";
import './HomePage.css';

//
//api left
//

export function HomePage() {
    const [rides, setRides] = useState([]);
    const userId = localStorage.getItem("userId");

    useEffect(() => {
        const fetchPendingRides = async () => {
            try {
                const res = await axios.get("/api/rides?status=pending");
                //const otherRides = res.data.filter(ride => ride.driver.id !== userId);
                const otherRides = res.data;
                setRides(otherRides);
            } catch (err) {
                console.error("Failed to fetch rides", err);
            }
        };

        fetchPendingRides();
    }, [userId]);
    return (
        <>
            <Header />

            <section className="hero">
                <div className="container">
                    <div className="hero-content">
                        <div className="motorcycle-animation">
                            <div className="motorcycle">🏍</div>
                        </div>
                        <h1 className="hero-title">A Verified & On-the-go Ride Sharing Platform</h1>
                        <p className="hero-subtitle">Safe, reliable and affordable rides across Bangladesh</p>
                        <div className="hero-buttons">
                            <Link to="/postride" className="btn-primary large">Post A Ride</Link>
                            <Link to="/findride" className="btn-primary large">Find A Ride</Link>
                        </div>
                    </div>
                </div>
            </section>

            <section className="available-rides">
                <div className="container">
                    <div className="section-header">
                        <h2>Available Rides</h2>
                        <div className="view-more">
                            <Link to="/findride" className="view-more"><span>View More <span className="arrow">→</span></span></Link>
                        </div>
                    </div>

                    <div className="rides-grid">
                        {rides.slice(0, 2).map((r, i) => (
                            <RideCard
                                key={i}
                                ride={r}
                                showRequest={false}
                                showStatus={false}
                            />
                        ))}
                    </div>
                </div>
            </section>

            <Footer />
        </>
    );
}