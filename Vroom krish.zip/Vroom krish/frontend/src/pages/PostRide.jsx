import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import axios from "axios";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";

export function PostRide() {
  const [formData, setFormData] = useState({
    locFrom: "",
    locTo: "",
    rideTime: "",
    vehicleid: "",
    fareRate: "",
  });

  const [vehicles, setVehicles] = useState([]);
  const navigate = useNavigate();

  // Load user role & vehicles
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userId = localStorage.getItem("userId");
        if (!userId) return;
        console.log("User ID:", userId);

        // Fetch role
        const userRes = await axios.get(`/api/users/${userId}`);
        const userRole = userRes.data.role;
        console.log("User:", userRes.data);

        if (userRole.toLowerCase() === "passenger") {
          alert("Register a vehicle first");
          navigate("/register");
          return;
        }

        // Check for pending rides
        const rideResp = await axios.get(`/api/ridepay/drvStatus?driverId=${userId}&status=ON_GOING`);
        if (rideResp.data.length > 0) {
          navigate("/confirm");
        }

        const rideRes = await axios.get(`/api/ridepay/drvStatus?driverId=${userId}&status=PENDING`);
        if (rideRes.data.length > 0) {
          navigate("/track");
        }

        // Fetch vehicles
        const vehicleRes = await axios.get(`/api/vehicles/${userId}`);
        console.log("Vehicles:", vehicleRes.data);
        setVehicles(vehicleRes.data);
      } catch (err) {
        console.error("Failed to load user/vehicles", err);
      }
    };

    fetchUserData();
  }, [navigate]);

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.locFrom === formData.locTo) {
      alert("Select a different destination.");
      return;
    }

    if (!formData.locFrom || !formData.locTo || !formData.rideTime || !formData.vehicleid || !formData.fareRate) {
      alert("Please fill all required fields.");
      return;
    }

    try {
      const userId = localStorage.getItem("userId");
      console.log(formData);

      const rideData = {
        locFrom: formData.locFrom,
        locTo: formData.locTo,
        rideTime: formData.rideTime,
        fare: formData.fareRate,
        vehicle: { id: formData.vehicleid }, // Send only vehicle id
        driver: { id: userId },  // Send only driver id
        rider: { id: 1 },  // Empty rider id (if needed)
        status: "PENDING",
        method: "NONE",
      };
      console.log("Posting ride:", rideData);
      await axios.post("/api/ridepay", rideData);

      navigate("/track");
    } catch (err) {
      console.error(err);
      alert("Failed to post ride. Please try again.");
    }
  };

  return (
    <>
      <Header />
      <div style={{ height: "100px" }}></div>
      <section className="post-ride-section">
        <div className="container">
          <div className="post-ride-header">
            <h1>Post A Ride</h1>
            <p>Fill in the details of your ride below.</p>
          </div>
          <div style={{ height: "25px" }}></div>

          <form className="post-ride-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label>From</label>
              <input
                type="text"
                name="locFrom"
                value={formData.locFrom}
                onChange={handleChange}
                placeholder="Enter departure city"
                required
              />
            </div>

            <div className="form-group">
              <label>To</label>
              <input
                type="text"
                name="locTo"
                value={formData.locTo}
                onChange={handleChange}
                placeholder="Enter destination city"
                required
              />
            </div>

            <div className="form-group">
              <label>Date & Time</label>
              <input type="datetime-local" name="rideTime" value={formData.rideTime} onChange={handleChange} required />
            </div>

            {/* Vehicle dropdown from DB */}
            <div className="form-group">
              <label>Select Vehicle</label>
              <select name="vehicleid" value={formData.vehicleid} onChange={handleChange} required>
                <option value="" disabled>Select one of your vehicles</option>
                {vehicles.map(v => (
                  <option key={v.id} value={v.id}>
                    {v.model} ({v.license})
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>Fare</label>
              <input type="number" name="fare" value={formData.fare} onChange={handleChange} required step="1" min="1" />
            </div>

            <button type="submit" className="btn-primary">Post Ride</button>
          </form>
          <div style={{ height: "50px" }}></div>
        </div>
      </section>
      <Footer />
    </>
  );
}
